WARNING: this tool MAY NOT work on your end. i have tested it on 8 different computers now, and had it work on each one, but every installation and computer is different. 

if you have any questions, comments, or inquiries, or you would like to report an issue relating to any of the features of this program NOT WORKING, please email me at sndrec32exe@gmail.com

you can find the source code of this program at the following link: https://github.com/sndrec/MouseThingy


HOW TO USE
----------

1. launch your game
2. go into your custom keyboard settings, and rebind your "look up/down/left/right" to something OTHER than your mouse. this disables the game's default mouse input completely.
3. load your game into a map. it can be singleplayer or multiplayer.
4. launch The Halo 2 Fixer Upper.exe
5. select the halo2 process from the process list at the top of the program.
6. hit activate.

the sensitivity at 90 FoV should be almost exactly equal to the sensitivity of any Source Engine game (team fortress 2, counter strike global offensive, etc) so use that as a baseline.

----------

at this point, you're finished, and you should have /much better/ aiming input on Halo 2 Vista. the program also includes Field-of-View and crosshair offset adjustment, in case you prefer to have a wider view, or a centered crosshair.

i'll reiterate one last time, if you have question, comments, or inquiries, or you would like to report an issue relating to any of the features of this program NOT WORKING, please email me at sndrec32exe@gmail.com

----------
special thanks
----------
TheAsuro - started out the base of the program
YaLTeR - helped fixed up the mouse input
supersniper - provided some extremely useful addresses for FoV
